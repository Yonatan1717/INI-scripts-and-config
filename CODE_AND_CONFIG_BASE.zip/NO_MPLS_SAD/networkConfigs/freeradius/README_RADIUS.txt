FreeRADIUS / 802.1X generated configuration
===========================================

RADIUS server IP: 10.1.10.10
Authentication port: 1812/UDP
Accounting port: 1813/UDP

1. Install FreeRADIUS (Ubuntu/Debian):
   sudo apt update && sudo apt install freeradius freeradius-utils

2. Append the contents of clients_network_switches.conf to the active
   FreeRADIUS clients.conf (commonly /etc/freeradius/3.0/clients.conf).

3. Configure users/certificates and an EAP method separately. The generator
   intentionally does not create a default username/password.

4. Validate before restart:
   sudo freeradius -XC
   sudo freeradius -X

The generated client IPs are the switches' MGMT SVI addresses. The switches
source RADIUS packets from their MGMT SVI, so these addresses must match.
